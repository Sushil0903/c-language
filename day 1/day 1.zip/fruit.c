#include <stdio.h>
int main()
{
    printf("Mango\t 10\n");
    printf("Orange\t 20\n");
    printf("banana\t 30\n");
    printf("kiwi\t 40\n");
    printf("Dragon\t 50\n");
    printf("watermelon\t60\n");
    printf("pumkin\t 70\n");
    printf("Apple\t 80\n");
    printf("muskmelon\t 90\n");
    printf("guvava\t 100\n");

    return 0;
}