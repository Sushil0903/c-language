#include <stdio.h>
int main()
{
    printf("-----------------\n");
    printf("A\t\t|\n");
    printf("B\t\t|\n");
    printf("C\t\t|\n");
    printf("D\t\t|\n");
    printf("E\t\t|\n");
    printf("-----------------\n");

    



}