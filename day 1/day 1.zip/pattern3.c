#include <stdio.h>
int main()
{
    printf("*\n");
    printf("*\n");
    printf("*\n");
    printf("*\t     * *\t\t  *\n");
    printf("*\t   *\t *\t        *\n");
    printf("*\t *\t   *\t      *\n");
    printf("*      *\t     *\t    *\n");
    printf("*    *\t\t\t* *\n");
    printf("*  *\n");
    printf("*");


}