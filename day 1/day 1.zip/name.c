#include <stdio.h>
int main()
{
    printf("Name: Sushil\n");
    printf("Age: 18\n");
    printf("School: Red & white\n");

    return 0;


}